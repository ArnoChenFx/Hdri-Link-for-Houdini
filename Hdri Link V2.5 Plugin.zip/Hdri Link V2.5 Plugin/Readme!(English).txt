1.Put the "houdini" folder into the HOUDINI install folder (example: Houdini XX.X)
2.Watch install video
3.Select your GSG HDRI Suit folder path (example: F:\HDRI-Packets\GSG-Links).
GSG HDRI Suit :https://greyscalegorilla.com/downloads/category/rendering/


support: Redshift/Arnold/Mantra/Octane/renderman RENDER.

Only support Windows system.

Work well in houdini16/16.5 , other virsion are not tested.


If you do not have GSG HDRI Suit and you also want to ues the tool:

1.Create a new folder to put your hdri file,can named "HDRI_Packs".

2.Create a new folder in the "HDRI_Packs", can named "Mypack01".

2.In the "Mypack01",Create two folders one named "HDRIs" the other named "Thumbnails".

3.Put your HDRIs into the "HDRIs" folder.

4.Convert your HDRIs' format to jpg .

5.Put the jpg pictures into "Thumbnails" folder.
 h
6.Now "HDRIs" folder have HDRIs which format is EXR or HDR,"Thumbnails" folder have HDRI preview file which format is jpg.

7.Write your "HDRI_Packs" path in to "Hdri_Path.txt",and your HDRIs can works well in the tool.